# skin.confluencetdoe
MOD of skin.confluence for kodi 18 

Added the Plugin Support for:
- plugin.program.tvhighlights
- plugin.program.newscenter
- script.pvrepg
- plugin.program.fhemcontrol
- service.remotekodi
- plugin.video.amazon-test
- plugin.audio.prime_music
- plugin.audio.radio_de
- plugin.video.skygo.de
- service.kn.switchtimer


Lot of modifications especially within the PVR section
Multiple Plugins are now integrated directly.

